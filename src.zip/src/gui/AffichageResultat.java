package gui;

import javax.swing.*;
import java.awt.*;

public class AffichageResultat extends JPanel {
    private Data data;
    private double[][] label;
    private Modele modele;
    private double[][] donnee;
    private double[][] predictedLabels;

    public AffichageResultat(Data data, Modele modele) {
        super();
        this.setBackground(Color.WHITE); // Fallback background
        this.setPreferredSize(new Dimension(335, 335));
        this.setLayout(new FlowLayout());
        
        this.data = data;
        this.modele = modele;
        this.donnee = data.getData();
        this.label = data.getResult();
        updatePredictions();

        // Observe model changes to update predictions
        modele.addObserver((o, arg) -> {
            updatePredictions();
            repaint();
        });

        // Observe data changes
        data.addObserver((o, arg) -> {
            this.donnee = data.getData();
            this.label = data.getResult();
            updatePredictions();
            repaint();
        });
    }

    private void updatePredictions() {
        this.donnee = data.getData();
        this.predictedLabels = modele.getPredictions();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // Clear the background
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (donnee == null || donnee.length == 0 || predictedLabels == null) {
            g2.setColor(Color.BLACK);
            g2.drawString("No data or predictions to display", 50, 200);
            return;
        }

        // Find data range for scaling
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE;
        double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (double[] point : donnee) {
            minX = Math.min(minX, point[0]);
            maxX = Math.max(maxX, point[0]);
            minY = Math.min(minY, point[1]);
            maxY = Math.max(maxY, point[1]);
        }
        double rangeX = maxX - minX;
        double rangeY = maxY - minY;
        if (rangeX == 0) rangeX = 1; // Avoid division by zero
        if (rangeY == 0) rangeY = 1;

        // Define margins and plot size
        int margin = 30;
        int plotSize = Math.min(getWidth(), getHeight()) - 2 * margin;

        // Calculate class density for gradient background
        int gridSize = 20; // 20x20 grid for density estimation
        int[][] class0Count = new int[gridSize][gridSize];
        int[][] class1Count = new int[gridSize][gridSize];
        
        // Count points in each grid cell
        for (int i = 0; i < donnee.length; i++) {
            double abscisse = donnee[i][0];
            double ordonnee = donnee[i][1];
            // Scale to grid
            int gridX = (int) (((abscisse - minX) / rangeX) * gridSize);
            int gridY = (int) (((maxY - ordonnee) / rangeY) * gridSize); // Flip y-axis
            gridX = Math.min(Math.max(gridX, 0), gridSize - 1); // Clamp to grid
            gridY = Math.min(Math.max(gridY, 0), gridSize - 1);
            
            // Increment count based on label
            if (predictedLabels[i][0] == 1) {
                class1Count[gridX][gridY]++;
            } else {
                class0Count[gridX][gridY]++;
            }
        }

        // Draw gradient background based on class density
        int cellWidth = plotSize / gridSize;
        int cellHeight = plotSize / gridSize;
        for (int gx = 0; gx < gridSize; gx++) {
            for (int gy = 0; gy < gridSize; gy++) {
                int total = class0Count[gx][gy] + class1Count[gx][gy];
                float ratio = total > 0 ? (float) class1Count[gx][gy] / total : 0.5f; // Default to neutral if no points
                // Interpolate between blue (class 0) and red (class 1)
                Color color = interpolateColor(Color.CYAN, Color.PINK, ratio);
                g2.setColor(color);
                int x = margin + gx * cellWidth;
                int y = margin + gy * cellHeight;
                g2.fillRect(x, y, cellWidth, cellHeight);
            }
        }

        // Draw points
        float pointSize = 6f; // Size of each point
        for (int i = 0; i < donnee.length; i++) {
            double abscisse = donnee[i][0];
            double ordonnee = donnee[i][1];
            
            g2.setColor(label[i][0] == 1 ? Color.RED : Color.BLUE);

            // Scale coordinates to plot area
            int x = margin + (int) ((abscisse - minX) / rangeX * plotSize);
            int y = margin + (int) ((maxY - ordonnee) / rangeY * plotSize); // Flip y-axis

            // Draw filled circle
            g2.fillOval(x - (int)(pointSize/2), y - (int)(pointSize/2), (int)pointSize, (int)pointSize);
        }

        // Draw axes
        g2.setColor(Color.BLACK);
        g2.drawLine(margin, margin + plotSize, margin + plotSize, margin + plotSize); // x-axis
        g2.drawLine(margin, margin, margin, margin + plotSize); // y-axis

        // Draw axis labels
        g2.setFont(new Font("Arial", Font.PLAIN, 12));
        g2.drawString(String.format("%.1f", minX), margin - 10, margin + plotSize + 15);
        g2.drawString(String.format("%.1f", maxX), margin + plotSize - 20, margin + plotSize + 15);
        g2.drawString(String.format("%.1f", minY), margin - 30, margin + plotSize);
        g2.drawString(String.format("%.1f", maxY), margin - 30, margin + 5);
    }

    // Helper method to interpolate between two colors
    private Color interpolateColor(Color start, Color end, float ratio) {
        float r = start.getRed() + ratio * (end.getRed() - start.getRed());
        float g = start.getGreen() + ratio * (end.getGreen() - start.getGreen());
        float b = start.getBlue() + ratio * (end.getBlue() - start.getBlue());
        return new Color(r / 255f, g / 255f, b / 255f);
    }
}